package fiturprogram;

import java.sql.SQLException;
import database.Database;

public class fitur extends Database {
    
//Connect ke Database ==========================================================
    public fitur() throws ClassNotFoundException, SQLException {
        super();
    }

//Syntax Insert ================================================================
    public void insertdata(String nama, String jobdesk, String bagian) throws SQLException {
        String sql = String.format("INSERT INTO karyawan (nama,jobdesk,bagian) VALUE ('%s','%s','%s')",
        nama, jobdesk, bagian);
        this.setQuery(sql);
        this.execute();
    }

//Syntax Show ==================================================================
    public void getdata() throws SQLException {
        String sql = "SELECT * FROM karyawan";
        this.setQuery(sql);
        this.fetch();
    }
    
//Syntax cari ID ===============================================================
    public void getid() throws SQLException {
    String sql = "SELECT id FROM karyawan";
    this.setQuery(sql);
    this.fetch();
    }
    
//Syntax Delete ================================================================
    public void deletedata(int id) throws SQLException {
        String sql = String.format("DELETE FROM karyawan WHERE id = %d", id);
        this.setQuery(sql);
        this.execute();
    }

//Show Tabel ===================================================================
    public String[][] showdata(boolean display_number) throws SQLException {
        String[][] data = new String[this.lendata()][4];
        getdata();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            if(display_number){
            data[i][0] =  Integer.toString(i+1);
            }
            else{data[i][0] =  Integer.toString(this.value.getInt("id"));}
            data[i][1] = this.value.getString("nama");
            data[i][2] = this.value.getString("jobdesk");
            data[i][3] = this.value.getString("bagian");
            i++;
        }
        return data;
    }
    
    public int lendata() throws SQLException {
        getdata();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
}
