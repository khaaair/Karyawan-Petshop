package fiturprogram;

public interface extras {
    public String loginfailed();
}

