package fiturprogram;

public class notifikasi implements extras{
    public String loginfailed(){
        return "Invalid Username/Password!";
    
    };
}

