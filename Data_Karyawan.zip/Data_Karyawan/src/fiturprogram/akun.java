package fiturprogram;

public class akun { 
    
    public String username;
    public String password;
    public void dataadmin(){
        username = "";
        password = "";
    }
    
    public void credit(String deskripsi1){
        System.out.println(deskripsi1);}
    
}


