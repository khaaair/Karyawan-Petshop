package fiturprogram;

public class admin extends akun {
//Overriding ===================================================================
    @Override
    public void dataadmin(){
        username = "admin";
        password = "1234";
    }
    
//Overloading ==================================================================
    public String credit(String deskripsi1, String deskripsi2){
       return(deskripsi1 + deskripsi2);}
    
}
